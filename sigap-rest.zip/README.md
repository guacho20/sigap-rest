## Aplication

Backend generado con nodejs pg express nodemon cors jwt typeorm bcrypt

### Ejecutar el proyecto


### Actualizar repositorio local git
  - git fetch
  - git pull
  -- prueba de commit